<?php

// BotDetect PHP Captcha configuration options
// ---------------------------------------------------------------------------
$BotDetect->HelpLinkMode = HelpLinkMode::Image;

?>
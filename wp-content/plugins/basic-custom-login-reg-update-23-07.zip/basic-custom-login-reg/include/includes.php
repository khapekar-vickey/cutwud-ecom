<?php
require_once WPUM_ROOT. '/include/countrystate_city.php';
require_once WPUM_ROOT. '/include/login.php';
require_once WPUM_ROOT. '/form/frontend_login.php';
require_once WPUM_ROOT. '/include/user_list_fun.php';
require_once(WPUM_ROOT. '/admin_userprofile.php');
require_once WPUM_ROOT. '/form/frontend_registration.php';
require_once WPUM_ROOT. '/form/frontend_edit_profile.php';
require_once WPUM_ROOT. '/include/add_userdata.php';
require_once WPUM_ROOT. '/form/frontend_change_password.php';
require_once WPUM_ROOT. '/form/frontend_dashboard.php';
require_once WPUM_ROOT. '/include/change-password.php';
require_once WPUM_ROOT. '/include/lost-password.php';